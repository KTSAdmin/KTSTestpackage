using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

using Amazon.Lambda.Core;
using Amazon.Lambda.APIGatewayEvents;
using Newtonsoft.Json;
using Amazon.SQS;
using Amazon.SQS.Model;
using Amazon.Lambda.SQSEvents;
using Amazon.Lambda.Model;
using Amazon.Lambda;
using System.Data.SqlClient;
using System.Transactions;
using System.Collections;
using Amazon.CloudWatchLogs;
using Amazon.CloudWatchLogs.Model;
using Microsoft.Extensions.Logging;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using BL;
using System.Data;
using Amazon.StepFunctions;
using System.Threading;
using Amazon.Lambda.TestUtilities;
using System.Net.Http;
using System.Net.Http.Headers;
using Amazon.EventBridge;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace AWSMultiLambda
{
    public class Functions
    {

        //static string accessKey = System.Environment.GetEnvironmentVariable("AccessKey");
        //static string secret = System.Environment.GetEnvironmentVariable("SecretKey");
        //static string AWSRegion = System.Environment.GetEnvironmentVariable("AWSRegion");
        //private readonly ILogger<AmazonSQSClient> _logger;
        public Functions()
        {
        }
        static string accessKey = "AKIAYPETT54RS2IQMO55";
        static string secret = "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";
        static string AWSRegion = "us-west-1";
        /// <summary>
        /// Default constructor that Lambda will invoke.
        /// </summary>
        //public Functions(ILogger<AmazonSQSClient> log)
        //{
        //    _logger = log;
        //}


        /// <summary>
        /// A Lambda function to respond to HTTP Get methods from API Gateway
        /// </summary>
        /// <param name="request"></param>
        /// <returns>The API Gateway response.</returns>
        public APIGatewayProxyResponse Get(APIGatewayProxyRequest request, ILambdaContext context)
        {
            context.Logger.LogLine("Get Request\n");
            string sa = accessKey;
            string saa = System.Environment.GetEnvironmentVariable("Key");
            var response = new APIGatewayProxyResponse
            {
                StatusCode = (int)HttpStatusCode.OK,
                Body = "Hello AWS Serverless",
                Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
            };

            return response;
        }

        public APIGatewayProxyResponse Post(APIGatewayProxyRequest input, ILambdaContext context)
        {
            context.Logger.LogLine("Post Request\n");
            string requestBody = input.Body;
            Test objTest = JsonConvert.DeserializeObject<Test>(requestBody);
            var response = new APIGatewayProxyResponse
            {
                StatusCode = (int)HttpStatusCode.OK,
                Body = (string.IsNullOrWhiteSpace(objTest.Name) ? objTest.EmailAddress : objTest.Name) + " MULTI FUNCTION " + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss"),
                Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
            };
            return response;
        }

        public APIGatewayProxyResponse GetEmployee(APIGatewayProxyRequest input, ILambdaContext context)
        {
            context.Logger.LogLine("Post Request\n");

            string requestBody = input.Body;
            Test objTest = JsonConvert.DeserializeObject<Test>(requestBody);
            var response = new APIGatewayProxyResponse
            {
                StatusCode = (int)HttpStatusCode.OK,
                Body = "Get Employee" + (string.IsNullOrWhiteSpace(objTest.Name) ? objTest.EmailAddress : objTest.Name) + " MULTI FUNCTION " + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss"),
                Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
            };
            return response;
        }

        public APIGatewayProxyResponse CreateQueue(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                //BL.FunctionCallResult result = new BL.FunctionCallResult();
                //BL.ReadSQSMessage.AddVPC("CREATE QUEUE: " + input.Body + " " + DateTime.Now.ToString(), out result);

                Queue objTest = JsonConvert.DeserializeObject<Queue>(requestBody);
                var createQueueRequest = new CreateQueueRequest();
                createQueueRequest.QueueName = objTest.QueueName;
                createQueueRequest.Attributes.Add("FifoQueue", "true");
                createQueueRequest.Attributes.Add("ContentBasedDeduplication", "true");
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonSQSClient amazonSQSClient = new AmazonSQSClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = amazonSQSClient.CreateQueueAsync(createQueueRequest).Result;

                ////var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                //AmazonStepFunctionsClient req = new AmazonStepFunctionsClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                //var data1 = req.StartExecutionAsync(new Amazon.StepFunctions.Model.StartExecutionRequest() { Input = "{\"Name\":\"" + objTest.QueueName + "\"}", StateMachineArn = "arn:aws:states:us-west-1:582277656355:stateMachine:StepFunctionUsingSQS" }).Result;



                //Guid MessageGroupId = Guid.NewGuid();
                //Guid MessageDeduplicationId = Guid.NewGuid();
                //var sendRequest = new SendMessageRequest(data.QueueUrl, "Hi, Testing multi process from AWS lambda functions");
                //sendRequest.MessageGroupId = Convert.ToString(MessageGroupId);
                //sendRequest.MessageDeduplicationId = Convert.ToString(MessageDeduplicationId);
                //var dataa = amazonSQSClient.SendMessageAsync(sendRequest).Result;

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse MultiProcess(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                BL.ReadSQSMessage.Add("CREATE QUEUE: " + input.Body + " " + DateTime.Now.ToString(), out result);

                Queue objTest = JsonConvert.DeserializeObject<Queue>(requestBody);
                var createQueueRequest = new CreateQueueRequest();
                createQueueRequest.QueueName = objTest.QueueName;
                createQueueRequest.Attributes.Add("FifoQueue", "true");
                createQueueRequest.Attributes.Add("ContentBasedDeduplication", "true");
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonSQSClient amazonSQSClient = new AmazonSQSClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = amazonSQSClient.CreateQueueAsync(createQueueRequest).Result;

                Guid MessageGroupId = Guid.NewGuid();
                Guid MessageDeduplicationId = Guid.NewGuid();
                var sendRequest = new SendMessageRequest(data.QueueUrl, "Hi, Testing multi process from AWS lambda functions");
                sendRequest.MessageGroupId = Convert.ToString(MessageGroupId);
                sendRequest.MessageDeduplicationId = Convert.ToString(MessageDeduplicationId);
                var dataa = amazonSQSClient.SendMessageAsync(sendRequest).Result;

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(dataa),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse ListAllQueue(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                Queue objTest = JsonConvert.DeserializeObject<Queue>(requestBody);
                var lstQueuesRequest = new ListQueuesRequest();
                if (!string.IsNullOrWhiteSpace(objTest.QueueNamePrefix))
                    lstQueuesRequest.QueueNamePrefix = objTest.QueueNamePrefix;
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonSQSClient amazonSQSClient = new AmazonSQSClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = amazonSQSClient.ListQueuesAsync(lstQueuesRequest).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse DeleteQueue(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                Queue objTest = JsonConvert.DeserializeObject<Queue>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonSQSClient amazonSQSClient = new AmazonSQSClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var deleteRequest = new DeleteQueueRequest
                {
                    QueueUrl = objTest.QueueUrl
                };
                var s = amazonSQSClient.DeleteQueueAsync(deleteRequest).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(s),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse GetQueueUrl(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                Queue objTest = JsonConvert.DeserializeObject<Queue>(requestBody);
                var lstQueuesRequest = new GetQueueUrlRequest();
                lstQueuesRequest.QueueName = objTest.QueueName;
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonSQSClient amazonSQSClient = new AmazonSQSClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = amazonSQSClient.GetQueueUrlAsync(lstQueuesRequest).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse GetQueueAttributes(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                Queue objTest = JsonConvert.DeserializeObject<Queue>(requestBody);
                var lstQueuesRequest = new GetQueueAttributesRequest();
                lstQueuesRequest.QueueUrl = objTest.QueueUrl;
                lstQueuesRequest.AttributeNames = new List<string>() { "All" };
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonSQSClient amazonSQSClient = new AmazonSQSClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = amazonSQSClient.GetQueueAttributesAsync(lstQueuesRequest).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public SQSBatchResponse ReadSQSMessages(SQSEvent sqsEvent, ILambdaContext context)
        {
            List<SQSBatchResponse.BatchItemFailure> batchItemFailures = new List<SQSBatchResponse.BatchItemFailure>();
            try
            {
                context.Logger.LogLine($"Beginning to process {sqsEvent.Records.Count} records...");
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                foreach (var record in sqsEvent.Records)
                {
                    context.Logger.LogLine($"Message ID: {record.MessageId}");
                    Console.WriteLine($"Event Source: {record.EventSource}");
                    Console.WriteLine($"Event SourceARN: {record.EventSourceArn}");

                    context.Logger.LogLine($"Record Body:");
                    context.Logger.LogLine(record.Body);
                    try
                    {
                        //process your message
                        int id = BL.ReadSQSMessage.Add(record.Body, out result);
                        if (result.Status != BL.ResultStatus.SUCCESS)
                            throw new Exception(result.Message);
                        context.Logger.LogLine("Added : " + id);
                    }
                    catch (Exception e)
                    {
                        context.Logger.LogLine("Error : " + e.Message + " " + record.MessageId);
                        //Add failed message identifier to the batchItemFailures list
                        batchItemFailures.Add(new SQSBatchResponse.BatchItemFailure { ItemIdentifier = record.MessageId });
                    }
                }
                context.Logger.LogLine("Processing complete.");
                context.Logger.LogLine($"Processed {sqsEvent.Records.Count} records.");
                return new SQSBatchResponse(batchItemFailures);

            }
            catch (Exception ex)
            {
                context.Logger.LogLine($"Error {ex.Message}");
                return new SQSBatchResponse(batchItemFailures);
            }
        }

        public static int Add(string content, out BL.FunctionCallResult result)
        {
            int id = 0;
            try
            {
                result = new BL.FunctionCallResult { Status = BL.ResultStatus.SUCCESS };
                using (TransactionScope scope = new TransactionScope())
                {
                    id = DALAdd(content);
                    scope.Complete();
                }
                return id;
            }
            catch (Exception ex)
            {
                result = new BL.FunctionCallResult
                {
                    Status = BL.ResultStatus.ERROR,
                    Exception = ex,
                    Message = ex.Message
                };
                return id;
            }
        }
        static string ConnectionString = "Data Source=kavniyaawsdb.csgie8kifj19.us-west-1.rds.amazonaws.com,1433;Initial Catalog=UserAWS;Pooling=true;user=admin;password=rx4DyMdUlC3817OMZTaS;";
        public static int DALAdd(string content)
        {
            using (SqlConnection sqlConnection = new SqlConnection(ConnectionString))
            {
                string sQuery = @"Insert into ReadSQSMessage
                                 (Content)
                                 values
                                (@Content) Select scope_identity()";
                SqlCommand cmd = new SqlCommand(sQuery, sqlConnection);
                cmd.Parameters.AddWithValue("@Content", content);
                for (int i = 0; i < cmd.Parameters.Count; i++)
                {
                    cmd.Parameters[i].IsNullable = true;
                    if (cmd.Parameters[i].Value == null || string.IsNullOrEmpty(cmd.Parameters[i].Value.ToString()))
                        cmd.Parameters[i].Value = DBNull.Value;
                }
                sqlConnection.Open();
                object obj = cmd.ExecuteScalar();
                cmd = null;
                sqlConnection.Close();
                return int.Parse(obj.ToString());
            }
        }
        public APIGatewayProxyResponse CreateEventSourceMapping(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                EventSourceMapping objEventSourceMapping = JsonConvert.DeserializeObject<EventSourceMapping>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                CreateEventSourceMappingResponse objcreateEventSourceMappingResponse = new CreateEventSourceMappingResponse();
                using (AmazonLambdaClient lambdaClient = new AmazonLambdaClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion)))
                {
                    objcreateEventSourceMappingResponse = lambdaClient.CreateEventSourceMappingAsync(new CreateEventSourceMappingRequest
                    {
                        BatchSize = 10,
                        EventSourceArn = objEventSourceMapping.EventSourceArn,
                        FunctionName = objEventSourceMapping.FunctionName,
                        FunctionResponseTypes = new List<string> { "ReportBatchItemFailures" },
                    }).Result;
                };

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(objcreateEventSourceMappingResponse),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse UpdateEventSourceMapping(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                EventSourceMapping objEventSourceMapping = JsonConvert.DeserializeObject<EventSourceMapping>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                UpdateEventSourceMappingResponse res = new UpdateEventSourceMappingResponse();
                using (AmazonLambdaClient lambdaClient = new AmazonLambdaClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion)))
                {
                    res = lambdaClient.UpdateEventSourceMappingAsync(new UpdateEventSourceMappingRequest
                    {
                        Enabled = objEventSourceMapping.Enabled,
                        UUID = objEventSourceMapping.UUID,
                        FunctionResponseTypes = new List<string> { "ReportBatchItemFailures" },
                    }).Result;
                };

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(res),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse GetFunction(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                EventSourceMapping objEventSourceMapping = JsonConvert.DeserializeObject<EventSourceMapping>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                using (AmazonLambdaClient lambdaClient = new AmazonLambdaClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion)))
                {
                    var da = lambdaClient.GetFunctionAsync(new GetFunctionRequest
                    {
                        FunctionName = "arn:aws:lambda:us-west-1:582277656355:function:kavniyaawsstack-ReadSQSMessages-XzVxA0bI1wpX", // Either FunctionARN or Function Name from ListFunction call response.
                    }).Result;
                };

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = "GetFunction",
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse AddDataToDB(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                Test objEventSourceMapping = JsonConvert.DeserializeObject<Test>(requestBody);
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                int id = Add(objEventSourceMapping.Name, out result);
                if (result.Status != BL.ResultStatus.SUCCESS)
                    throw new Exception(result.Message);
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = "AddDataToDB",
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }
        private const string MaxReceiveCount = "1";
        private const string ReceiveMessageWaitTime = "2";
        private const int MaxArgs = 3;
        public APIGatewayProxyResponse CreateQueueWithDLQ(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                Queue objTest = JsonConvert.DeserializeObject<Queue>(requestBody);

                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonSQSClient amazonSQSClient = new AmazonSQSClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var deadLetterQueueUrl = CreateQueue_Test(amazonSQSClient, "DLQ_" + objTest.QueueName).Result;
                var messageQueueUrl = CreateQueue_Test(amazonSQSClient, objTest.QueueName, deadLetterQueueUrl.QueueUrl, MaxReceiveCount, ReceiveMessageWaitTime).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(messageQueueUrl),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        private static async Task<CreateQueueResponse> CreateQueue_Test(
      IAmazonSQS sqsClient, string qName, string deadLetterQueueUrl = null,
      string maxReceiveCount = null, string receiveWaitTime = null)
        {
            var createQueueRequest = new CreateQueueRequest();
            createQueueRequest.QueueName = qName;
            createQueueRequest.Attributes.Add("FifoQueue", "true");
            createQueueRequest.Attributes.Add("ContentBasedDeduplication", "true");
            var attrs = new Dictionary<string, string>();

            // If a dead-letter queue is given, create a message queue
            if (!string.IsNullOrEmpty(deadLetterQueueUrl))
            {
                createQueueRequest.Attributes.Add(QueueAttributeName.ReceiveMessageWaitTimeSeconds, receiveWaitTime);
                createQueueRequest.Attributes.Add(QueueAttributeName.RedrivePolicy,
                  $"{{\"deadLetterTargetArn\":\"{await GetQueueArn(sqsClient, deadLetterQueueUrl)}\"," +
                  $"\"maxReceiveCount\":\"{maxReceiveCount}\"}}");
                // Add other attributes for the message queue such as VisibilityTimeout
            }

            // If no dead-letter queue is given, create one of those instead
            //else
            //{
            //  // Add attributes for the dead-letter queue as needed
            //  attrs.Add();
            //}

            // Create the queue
            CreateQueueResponse responseCreate = sqsClient.CreateQueueAsync(createQueueRequest).Result;
            return responseCreate;
        }

        private static async Task<string> GetQueueArn(IAmazonSQS sqsClient, string qUrl)
        {
            GetQueueAttributesResponse responseGetAtt = await sqsClient.GetQueueAttributesAsync(
              qUrl, new List<string> { QueueAttributeName.QueueArn });
            return responseGetAtt.QueueARN;
        }

        public APIGatewayProxyResponse SendSQSMessages(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                Message objTest = JsonConvert.DeserializeObject<Message>(requestBody);
                IAmazonSQS _sqs = new AmazonSQSClient();
                Guid MessageGroupId = Guid.NewGuid();
                Guid MessageDeduplicationId = Guid.NewGuid();
                var sendRequest = new SendMessageRequest(objTest.QueueURL, objTest.Msg);
                if (objTest.IsFifo)
                {
                    sendRequest.MessageGroupId = Convert.ToString(MessageGroupId);
                    sendRequest.MessageDeduplicationId = Convert.ToString(MessageDeduplicationId);
                }
                sendRequest.MessageAttributes = new Dictionary<string, MessageAttributeValue>() { { "SourceURL", new MessageAttributeValue { DataType = "String", StringValue = objTest.QueueURL } } };
                //var sendResult = _sqs.SendMessageAsync(sendRequest);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonSQSClient amazonSQSClient = new AmazonSQSClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = amazonSQSClient.SendMessageAsync(sendRequest).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse SendSQSMessagesLoop(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                Message objTest = JsonConvert.DeserializeObject<Message>(requestBody);
                IAmazonSQS _sqs = new AmazonSQSClient();
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonSQSClient amazonSQSClient = new AmazonSQSClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = new SendMessageResponse();
                for (int i = 0; i < objTest.MessageCount; i++)
                {
                    Guid MessageGroupId = Guid.NewGuid();
                    Guid MessageDeduplicationId = Guid.NewGuid();
                    var sendRequest = new SendMessageRequest(objTest.QueueURL, $"{objTest.Msg} {i + 1}");
                    if (objTest.IsFifo)
                    {
                        sendRequest.MessageGroupId = Convert.ToString(MessageGroupId);
                        sendRequest.MessageDeduplicationId = Convert.ToString(MessageDeduplicationId);
                    }
                    sendRequest.MessageAttributes = new Dictionary<string, MessageAttributeValue>() { { "SourceURL", new MessageAttributeValue { DataType = "String", StringValue = objTest.QueueURL } } };
                    //var sendResult = _sqs.SendMessageAsync(sendRequest);                
                    data = amazonSQSClient.SendMessageAsync(sendRequest).Result;
                }
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse DeleteSQSMessages(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                //ILogger<AmazonSQSClient> _logger = new Logger<Task>();
                string requestBody = input.Body;
                DeleteMessage objTest = JsonConvert.DeserializeObject<DeleteMessage>(requestBody);

                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonSQSClient amazonSQSClient = new AmazonSQSClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                string body = string.Empty;
                string handlerID = ReturnMessageReceiptHandle(objTest.QueueUrl, objTest.MessageID, amazonSQSClient, out body);
                var data = amazonSQSClient.DeleteMessageAsync(objTest.QueueUrl, handlerID).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public string ReturnMessageReceiptHandle(string queueURL, string messageID, AmazonSQSClient amazonSQSClient, out string body)
        {
            string ReceiptHandle = string.Empty;
            var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
            body = string.Empty;
            var request = new ReceiveMessageRequest
            {
                AttributeNames = new List<string>() { "All" },
                MaxNumberOfMessages = 1,
                QueueUrl = queueURL,
                WaitTimeSeconds = 20
            };

            var data = amazonSQSClient.ReceiveMessageAsync(request).Result;

            if (data.Messages.Count > 0)
            {
                foreach (var message in data.Messages)
                {
                    if (message.MessageId == messageID)
                    {
                        ReceiptHandle = message.ReceiptHandle;
                        body = message.Body.Replace("Error", "No Issue");
                    }
                }
            }
            return ReceiptHandle;
        }

        public APIGatewayProxyResponse GetSQSMessages(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                Message objTest = JsonConvert.DeserializeObject<Message>(requestBody);
                var request = new ReceiveMessageRequest
                {
                    AttributeNames = new List<string>() { "All" },
                    QueueUrl = objTest.QueueURL,
                    MaxNumberOfMessages = 10,
                    WaitTimeSeconds = 20,
                    MessageAttributeNames = new List<string>() { "SourceURL" },
                };
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonSQSClient amazonSQSClient = new AmazonSQSClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = amazonSQSClient.ReceiveMessageAsync(request).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse GetAllSQSMessages(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                var call = new APIGatewayProxyResponse();
                int count = 0;
                do
                {
                    SendDeleteMessage objTest = JsonConvert.DeserializeObject<SendDeleteMessage>(requestBody);
                    var request = new ReceiveMessageRequest
                    {
                        AttributeNames = new List<string>() { "All" },
                        QueueUrl = objTest.DLQQueueUrl,
                        MaxNumberOfMessages = 10,
                        VisibilityTimeout = 2,
                        WaitTimeSeconds = 2,
                        MessageAttributeNames = new List<string>() { "SourceURL" },
                    };
                    var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                    AmazonSQSClient amazonSQSClient = new AmazonSQSClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                    var data = amazonSQSClient.ReceiveMessageAsync(request).Result;
                    count = data.Messages.Count;
                    foreach (var item in data.Messages)
                    {

                        var sendRequest = new SendMessageRequest(objTest.QueueUrl, item.Body.Replace("Error", "No Issue"));
                        sendRequest.MessageGroupId = Convert.ToString(Guid.NewGuid());
                        sendRequest.MessageDeduplicationId = Convert.ToString(Guid.NewGuid());
                        var data1 = amazonSQSClient.SendMessageAsync(sendRequest).Result;

                        APIGatewayProxyRequest i = new APIGatewayProxyRequest();
                        DeleteMessage msg = new DeleteMessage();
                        msg.QueueUrl = objTest.DLQQueueUrl;
                        msg.MessageID = item.MessageId;
                        i.Body = JsonConvert.SerializeObject(msg);
                        call = DeleteSQSMessages(i, context);
                    }
                } while (count > 0);

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(call),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse SendAndDeleteMessage(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                SendDeleteMessage objTest = JsonConvert.DeserializeObject<SendDeleteMessage>(requestBody);
                Guid MessageGroupId = Guid.NewGuid();
                Guid MessageDeduplicationId = Guid.NewGuid();
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonSQSClient amazonSQSClient = new AmazonSQSClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                string body = string.Empty;
                string handlerID = ReturnMessageReceiptHandle(objTest.DLQQueueUrl, objTest.MessageID, amazonSQSClient, out body);
                var sendRequest = new SendMessageRequest(objTest.QueueUrl, body);
                sendRequest.MessageGroupId = Convert.ToString(MessageGroupId);
                sendRequest.MessageDeduplicationId = Convert.ToString(MessageDeduplicationId);
                //var sendResult = _sqs.SendMessageAsync(sendRequest);

                var data = amazonSQSClient.SendMessageAsync(sendRequest).Result;

                var delete = amazonSQSClient.DeleteMessageAsync(objTest.DLQQueueUrl, handlerID).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse GetLogEvents(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                LogEvents objLogEvents = JsonConvert.DeserializeObject<LogEvents>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                IAmazonCloudWatchLogs amazonCloudWatchLogs = new AmazonCloudWatchLogsClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion)); // provide regionEndPoint
                List<GetLogEventsResponse> GetLogEvents = new List<GetLogEventsResponse>(); ;
                var describeLogStreamsRequest = new DescribeLogStreamsRequest()
                {
                    LogGroupName = objLogEvents.LogGroupName,
                    LogStreamNamePrefix = !string.IsNullOrEmpty(objLogEvents.LogStreamNamePrefix) ? objLogEvents.LogStreamNamePrefix : null
                };

                var describeLogStreamsResult = amazonCloudWatchLogs.DescribeLogStreamsAsync(describeLogStreamsRequest).Result;

                foreach (var stream in describeLogStreamsResult.LogStreams)
                {
                    var eventsRequest = new GetLogEventsRequest()
                    {
                        LogStreamName = stream.LogStreamName,
                        LogGroupName = describeLogStreamsRequest.LogGroupName
                    };
                    var result = amazonCloudWatchLogs.GetLogEventsAsync(eventsRequest).Result;
                    GetLogEvents.Add(result);
                }

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(GetLogEvents),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse GetLogStreams(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                LogEvents objLogEvents = JsonConvert.DeserializeObject<LogEvents>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                IAmazonCloudWatchLogs amazonCloudWatchLogs = new AmazonCloudWatchLogsClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion)); // provide regionEndPoint
                var describeLogStreamsRequest = new DescribeLogStreamsRequest()
                {
                    LogGroupName = objLogEvents.LogGroupName,
                    LogStreamNamePrefix = !string.IsNullOrEmpty(objLogEvents.LogStreamNamePrefix) ? objLogEvents.LogStreamNamePrefix : null
                };

                var describeLogStreamsResult = amazonCloudWatchLogs.DescribeLogStreamsAsync(describeLogStreamsRequest).Result;


                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(describeLogStreamsResult),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public class LogEvents
        {
            public string LogGroupName { get; set; }
            public string LogStreamNamePrefix { get; set; }
        }

        public class SendDeleteMessage
        {
            public string Msg { get; set; }
            public string MessageID { get; set; }
            public string DLQQueueUrl { get; set; }
            public string QueueUrl { get; set; }
        }
        public class DeleteMessage
        {
            public string MessageID { get; set; }
            public string QueueUrl { get; set; }
        }

        public class Test
        {
            public string Name { get; set; }
            public string EmailAddress { get; set; }
        }

        public class Message
        {
            public string Msg { get; set; }
            public string QueueURL { get; set; }
            public int MessageCount { get; set; }
            public bool IsFifo { get; set; }
        }

        public class Queue
        {
            public string QueueName { get; set; }
            public string QueueUrl { get; set; }
            public string QueueNamePrefix { get; set; }
        }

        public class EventSourceMapping
        {
            public string EventSourceArn { get; set; }
            public string FunctionName { get; set; }
            public string UUID { get; set; }
            public bool Enabled { get; set; }
            public int BatchSize { get; set; }
            public int MaximumBatchingWindowInSeconds { get; set; }
            public string Marker { get; set; }
        }
        public APIGatewayProxyResponse CreateDynamoDB(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                DynamoDB obj = JsonConvert.DeserializeObject<DynamoDB>(requestBody);
                BL.FunctionCallResult result = new BL.FunctionCallResult();

                //AmazonDynamoDBClient client = new AmazonDynamoDBClient();

                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonDynamoDBClient amazonSQSClient = new AmazonDynamoDBClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));

                var request = new CreateTableRequest
                {
                    TableName = obj.TableName,
                    AttributeDefinitions = new List<AttributeDefinition>()
                      {
                        new AttributeDefinition
                        {
                          AttributeName = obj.Partitionkey,
                          AttributeType = obj.PartitionType
                        }
                      },
                    KeySchema = new List<KeySchemaElement>()
                      {
                        new KeySchemaElement
                        {
                          AttributeName = obj.Partitionkey,
                          KeyType = obj.KeyType  //Partition key
                        }
                      },
                    ProvisionedThroughput = new ProvisionedThroughput
                    {
                        ReadCapacityUnits = 10,
                        WriteCapacityUnits = 5
                    }
                };

                var dbresponse = amazonSQSClient.CreateTableAsync(request).Result;

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = "DynamoDB Created",
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }


        public APIGatewayProxyResponse InsertDynamoDB(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                AddDynamoDB obj = JsonConvert.DeserializeObject<AddDynamoDB>(requestBody);
                BL.FunctionCallResult result = new BL.FunctionCallResult();

                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonDynamoDBClient amazonSQSClient = new AmazonDynamoDBClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var request = new PutItemRequest();
                request.TableName = obj.TableName;
                request.Item = new Dictionary<string, AttributeValue>();
                foreach (var item in obj.ParamList)
                {
                    if (item.Type == "N")
                    {
                        request.Item.Add(item.key, new AttributeValue { N = item.value });
                    }
                    else if (item.Type == "S")
                    {
                        request.Item.Add(item.key, new AttributeValue { S = item.value });
                    }
                }
                //request.Item.Add("Authors",
                //    new AttributeValue
                //    { SS = new List<string> { "Author1", "Author2" } });

                var dbresponse = amazonSQSClient.PutItemAsync(request).Result;

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = "Added Successfully",
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse EXEProcess(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                context.Logger.LogLine("Job Started");
                BL.FunctionCallResult result = new BL.FunctionCallResult();  //process your message
                context.Logger.LogLine("Do some process");
                int id = BL.ReadSQSMessage.Add(DateTime.Now.ToString(), out result);
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = "Success",
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                context.Logger.LogLine("Job Ended");
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                context.Logger.LogLine("Error in Job");
                return response;
            }
        }

        public class DynamoDB
        {
            public string TableName { get; set; }
            public string Partitionkey { get; set; }
            public string PartitionType { get; set; }
            public string KeyType { get; set; }
        }

        public class AddDynamoDB
        {
            public string TableName { get; set; }
            public List<ParamList> ParamList { get; set; }
        }

        public class ParamList
        {
            public string key { get; set; }
            public string value { get; set; }
            public string Type { get; set; }
        }

        public SQSBatchResponse InsertEmployee(SQSEvent sqsEvent, ILambdaContext context)
        {
            List<SQSBatchResponse.BatchItemFailure> batchItemFailures = new List<SQSBatchResponse.BatchItemFailure>();
            try
            {
                context.Logger.LogLine($"Beginning to process {sqsEvent.Records.Count} records...");
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                foreach (var record in sqsEvent.Records)
                {
                    context.Logger.LogLine($"Message ID: {record.MessageId}");
                    Console.WriteLine($"Event Source: {record.EventSource}");
                    Console.WriteLine($"Event SourceARN: {record.EventSourceArn}");

                    context.Logger.LogLine($"Record Body:");
                    context.Logger.LogLine(record.Body);
                    Employee obj = JsonConvert.DeserializeObject<Employee>(record.Body);
                    try
                    {
                        //process your message
                        int id = BL.ReadSQSMessage.AddEmployee(obj.EmployeeName, obj.Designation, obj.Salary, obj.Grade, out result);
                        if (result.Status != BL.ResultStatus.SUCCESS)
                            throw new Exception(result.Message);
                        context.Logger.LogLine("Added : " + id);
                    }
                    catch (Exception e)
                    {
                        context.Logger.LogLine("Error : " + e.Message + " " + record.MessageId);
                        //Add failed message identifier to the batchItemFailures list
                        batchItemFailures.Add(new SQSBatchResponse.BatchItemFailure { ItemIdentifier = record.MessageId });
                    }
                }
                context.Logger.LogLine("Processing complete.");
                context.Logger.LogLine($"Processed {sqsEvent.Records.Count} records.");
                return new SQSBatchResponse(batchItemFailures);

            }
            catch (Exception ex)
            {
                context.Logger.LogLine($"Error {ex.Message}");
                return new SQSBatchResponse(batchItemFailures);
            }
        }

        public APIGatewayProxyResponse GetEmployeeDetails(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                BL.FunctionCallResult result = new BL.FunctionCallResult();  //process your message
                List<Employee> lstEmployee = BLGetEmployeeDetails(out result);
                EmployeeResposne objEmployeeResposne = new EmployeeResposne();
                objEmployeeResposne.Employee = lstEmployee;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(objEmployeeResposne),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public class Employee
        {
            public int EmployeeID { get; set; }
            public string EmployeeName { get; set; }
            public string Designation { get; set; }
            public decimal Salary { get; set; }
            public string Grade { get; set; }
            public string Name { get; set; }
        }

        public class Input
        {
            public string Name { get; set; }
            public int ID { get; set; }
            public string TaskToken { get; set; }
        }

        public class POCOCallBack
        {
            public string Name { get; set; }
            public int ID { get; set; }
            public string TaskToken { get; set; }
        }

        public class EmployeeResposne
        {
            public List<Employee> Employee { get; set; }
        }

        public static List<Employee> BLGetEmployeeDetails(out FunctionCallResult result)
        {
            List<Employee> lstEmployee = new List<Employee>();
            Employee objEmployee = new Employee();
            try
            {
                result = new FunctionCallResult { Status = ResultStatus.SUCCESS };
                using (IDataReader rd = BL.ReadSQSMessage.GetEmployeeDetails())
                {
                    int _EmployeeID = rd.GetOrdinal("EmployeeID"),
                        _EmployeeName = rd.GetOrdinal("EmployeeName"),
                        _Designation = rd.GetOrdinal("Designation"),
                        _Salary = rd.GetOrdinal("Salary"),
                        _Grade = rd.GetOrdinal("Grade");

                    while (rd.Read())
                    {
                        objEmployee = new Employee();
                        if (!rd.IsDBNull(_EmployeeID)) objEmployee.EmployeeID = rd.GetInt32(_EmployeeID);
                        if (!rd.IsDBNull(_EmployeeName)) objEmployee.EmployeeName = rd.GetString(_EmployeeName);
                        if (!rd.IsDBNull(_Designation)) objEmployee.Designation = rd.GetString(_Designation);
                        if (!rd.IsDBNull(_Salary)) objEmployee.Salary = rd.GetDecimal(_Salary);
                        if (!rd.IsDBNull(_Grade)) objEmployee.Grade = rd.GetString(_Grade);
                        lstEmployee.Add(objEmployee);
                    }
                }
                return lstEmployee;
            }
            catch (Exception ex)
            {
                result = new FunctionCallResult { Status = ResultStatus.ERROR, Exception = ex, Message = ex.Message };
                return lstEmployee;
            }
        }

        public APIGatewayProxyResponse GetEventSourceMapping(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                EventSourceMapping objEventSourceMapping = JsonConvert.DeserializeObject<EventSourceMapping>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                GetEventSourceMappingResponse res = new GetEventSourceMappingResponse();
                using (AmazonLambdaClient lambdaClient = new AmazonLambdaClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion)))
                {
                    res = lambdaClient.GetEventSourceMappingAsync(new GetEventSourceMappingRequest()
                    {
                        UUID = objEventSourceMapping.UUID,
                    }).Result;
                };

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(res),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse ListFunctions(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                EventSourceMapping objEventSourceMapping = JsonConvert.DeserializeObject<EventSourceMapping>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                ListFunctionsResponse res = new ListFunctionsResponse();
                using (AmazonLambdaClient lambdaClient = new AmazonLambdaClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion)))
                {
                    res = lambdaClient.ListFunctionsAsync(new ListFunctionsRequest()
                    {
                        Marker = string.IsNullOrWhiteSpace(objEventSourceMapping.Marker) ? null : objEventSourceMapping.Marker
                    }).Result;
                };

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(res),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse ListEventSourceMapping(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                EventSourceMapping objEventSourceMapping = JsonConvert.DeserializeObject<EventSourceMapping>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                ListEventSourceMappingsResponse res = new ListEventSourceMappingsResponse();
                using (AmazonLambdaClient lambdaClient = new AmazonLambdaClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion)))
                {
                    res = lambdaClient.ListEventSourceMappingsAsync(new ListEventSourceMappingsRequest()
                    {
                    }).Result;
                };

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(res),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public async Task<Employee> SFCreateEmployee(Employee employee, ILambdaContext context)
        {
            try
            {
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                int id = BL.ReadSQSMessage.AddEmployee(employee.EmployeeName, employee.Designation, employee.Salary, employee.Grade, out result);
                if (result.Status != BL.ResultStatus.SUCCESS)
                    throw new Exception(result.Message);
                employee.EmployeeID = id;
                return employee;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<Input> SFCreateStudent(Input input, ILambdaContext context)
        {
            try
            {
                context.Logger.LogLine("Student call");
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                int id = BL.ReadSQSMessage.AddStudent(input.Name, out result);
                if (result.Status != BL.ResultStatus.SUCCESS)
                    throw new Exception(result.Message);
                input.ID = id;
                return input;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<Input> SFCreateUser(Input input, ILambdaContext context)
        {
            try
            {
                context.Logger.LogLine("User call");
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                int id = BL.ReadSQSMessage.AddUser(input.Name, out result);
                if (result.Status != BL.ResultStatus.SUCCESS)
                    throw new Exception(result.Message);
                input.ID = id;
                return input;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<Input> SFCreateRole(Input input, ILambdaContext context)
        {
            try
            {
                context.Logger.LogLine("Role call");
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                int id = BL.ReadSQSMessage.AddRole(input.Name, out result);
                if (result.Status != BL.ResultStatus.SUCCESS)
                    throw new Exception(result.Message);
                input.ID = id;
                return input;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<Employee> SFListEmployee(Employee employee, ILambdaContext context)
        {
            try
            {
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                List<Employee> lstEmployee = BLGetEmployeeDetails(out result);
                if (result.Status != BL.ResultStatus.SUCCESS)
                    throw new Exception(result.Message);
                return lstEmployee.Where(x => x.EmployeeID == employee.EmployeeID).FirstOrDefault();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public APIGatewayProxyResponse StartStepFunctionExecution(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                context.Logger.LogLine("Initiated" + "" + input.Body);
                BL.FunctionCallResult result = new BL.FunctionCallResult();                
                string requestBody = input.Body;
                CStartExecution obj = JsonConvert.DeserializeObject<CStartExecution>(requestBody);
                if (obj.name.Contains("DB"))
                {
                    BL.ReadSQSMessage.Add("StartStepFunctionExecution: " + input.Body + " " + DateTime.Now.ToString(), out result);
                    Thread.Sleep(5000);
                }
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonStepFunctionsClient req = new AmazonStepFunctionsClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));                
                var data = req.StartExecutionAsync(new Amazon.StepFunctions.Model.StartExecutionRequest() { Input = obj.input, Name = obj.name, StateMachineArn = obj.stateMachineArn, TraceHeader = obj.traceHeader }).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                context.Logger.LogLine("Call ended");
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                context.Logger.LogLine("Error" + ex.Message);
                return response;
            }
        }

        public APIGatewayProxyResponse UpdateStepFunction(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                UpdateStateMachineRequest obj = JsonConvert.DeserializeObject<UpdateStateMachineRequest>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonStepFunctionsClient req = new AmazonStepFunctionsClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = req.UpdateStateMachineAsync(new Amazon.StepFunctions.Model.UpdateStateMachineRequest()
                {
                    StateMachineArn = obj.StateMachineArn,
                    Definition = obj.Definition
                }).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse CreateStepFunction(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                CreateStateMachineRequest obj = JsonConvert.DeserializeObject<CreateStateMachineRequest>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonStepFunctionsClient req = new AmazonStepFunctionsClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = req.CreateStateMachineAsync(new Amazon.StepFunctions.Model.CreateStateMachineRequest()
                {
                    Name = obj.Name,
                    Definition = obj.Definition,
                    Type = Amazon.StepFunctions.StateMachineType.STANDARD,
                    RoleArn = obj.RoleArn
                }).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public class CStartExecution
        {
            public string input { get; set; }
            public string name { get; set; }
            public string stateMachineArn { get; set; }
            public string traceHeader { get; set; }
        }

        public class POCODescribeExecution
        {
            public string ExecutionArn { get; set; }
        }

        public class UpdateStateMachineRequest
        {
            public string Definition { get; set; }
            public string StateMachineArn { get; set; }
        }

        public class CreateStateMachineRequest
        {
            public string Name { get; set; }
            public string Definition { get; set; }
            public string RoleArn { get; set; }
        }   

        public async Task<Input> PoCAdd(Input input, ILambdaContext context)
        {
            try
            {
                context.Logger.LogLine("PoCAdd call");
                //context.Logger.LogLine("Sleep starts");
                //Thread.Sleep(15000);
                //context.Logger.LogLine("Sleep end");
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                int id = BL.ReadSQSMessage.Add("PoCAdd call:" + input.Name, out result);
                if (result.Status != BL.ResultStatus.SUCCESS)
                    throw new Exception(result.Message);
                input.ID = id;
                return input;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<Input> PoCEdit(Input input, ILambdaContext context)
        {
            try
            {
                context.Logger.LogLine("PoCEdit call");
                //Thread.Sleep(15000);
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                int id = BL.ReadSQSMessage.Add("PoCEdit call: " + input.Name, out result);
                if (result.Status != BL.ResultStatus.SUCCESS)
                    throw new Exception(result.Message);
                input.ID = id;
                return input;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<Input> PoCDelete(Input input, ILambdaContext context)
        {
            try
            {
                context.Logger.LogLine("PoCDelete call");
                //Thread.Sleep(15000);
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                int id = BL.ReadSQSMessage.Add("PoCDelete call " + input.Name, out result);
                if (result.Status != BL.ResultStatus.SUCCESS)
                    throw new Exception(result.Message);
                input.ID = id;
                return input;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<Input> PoCList(Input input, ILambdaContext context)
        {
            try
            {
                context.Logger.LogLine("PoCList call");
                //Thread.Sleep(15000);
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                int id = BL.ReadSQSMessage.Add("PoCList call: " + input.Name, out result);
                if (result.Status != BL.ResultStatus.SUCCESS)
                    throw new Exception(result.Message);
                input.ID = id;

                //TestLambdaContext context1;
                //APIGatewayProxyRequest request;
                //APIGatewayProxyResponse response;

                //Functions functions = new Functions();
                //request = new APIGatewayProxyRequest();
                //context1 = new TestLambdaContext();

                //request = new APIGatewayProxyRequest();
                //context = new TestLambdaContext();
                //CStartExecution sd = new CStartExecution();
                //Input i = new Input();
                //i.Name = input.Name;
                //sd.input = JsonConvert.SerializeObject(i);
                //sd.stateMachineArn = "arn:aws:states:us-west-1:582277656355:stateMachine:StepFunctionUsingSQS";
                //request.Body = JsonConvert.SerializeObject(sd);
                //functions.StartExecution(request, context);
                //context.Logger.LogLine("StartExecution called");

                return input;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public SQSBatchResponse QueueReadSQSMessages(SQSEvent sqsEvent, ILambdaContext context)
        {
            List<SQSBatchResponse.BatchItemFailure> batchItemFailures = new List<SQSBatchResponse.BatchItemFailure>();
            try
            {
                Guid MessageGroupId = Guid.NewGuid();
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                //BL.ReadSQSMessage.Add("Queue initiated: " + MessageGroupId + " " + DateTime.Now.ToString(), out result);
                context.Logger.LogLine($"Message Count : {sqsEvent.Records.Count}");
                context.Logger.LogLine($"Sleep started...");
                context.Logger.LogLine($"Beginning to process {sqsEvent.Records.Count} records...");

                foreach (var record in sqsEvent.Records)
                {
                    context.Logger.LogLine($"Message ID: {record.MessageId}");
                    Console.WriteLine($"Event Source: {record.EventSource}");
                    Console.WriteLine($"Event SourceARN: {record.EventSourceArn}");

                    context.Logger.LogLine($"Record Body:");
                    context.Logger.LogLine(record.Body);
                    try
                    {
                        //process your message
                        if (record.Body.Contains("Error"))
                            throw new Exception("Moved to DLQ");
                        int id = BL.ReadSQSMessage.Add((record.Body + " MSGID: " + record.MessageId + " GUID: " + MessageGroupId), out result);
                        if (result.Status != BL.ResultStatus.SUCCESS)
                            throw new Exception(result.Message);
                        context.Logger.LogLine("Added : " + id);
                        //context.Logger.LogLine("Start StartExecutionAsync");
                        //var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                        //AmazonStepFunctionsClient req = new AmazonStepFunctionsClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                        //var data = req.StartExecutionAsync(new Amazon.StepFunctions.Model.StartExecutionRequest() { Input = "{\"Name\":\"" + record.Body + "\"}", StateMachineArn = "arn:aws:states:us-west-1:582277656355:stateMachine:StepFunctionUsingSQS" }).Result;
                        //context.Logger.LogLine("End StartExecutionAsync");
                        //Object requestObj = new { input = "{\"Name\":\""+ record.Body + "\"}", stateMachineArn = "arn:aws:states:us-west-1:582277656355:stateMachine:StepFunctionUsingSQS" };
                        ////// Call REST Web API.  
                        //bool responseObj = PostInfo(requestObj).Result;
                        //if (!responseObj)
                        //    context.Logger.LogLine("Error");
                        //else
                        //    context.Logger.LogLine("Success");
                        //Input i = new Input();
                        //i.Name = record.Body;
                        //APIGatewayProxyRequest request = new APIGatewayProxyRequest();
                        //request.Body = "{\"QueueName\":\""+ record.Body + "\"}";
                        //CreateQueue(request, context);
                    }
                    catch (Exception e)
                    {
                        context.Logger.LogLine("Error : " + e.Message + " " + record.MessageId);
                        //Add failed message identifier to the batchItemFailures list
                        batchItemFailures.Add(new SQSBatchResponse.BatchItemFailure { ItemIdentifier = record.MessageId });
                    }
                }
                context.Logger.LogLine("Processing complete.");
                context.Logger.LogLine($"Processed {sqsEvent.Records.Count} records.");
                //BL.ReadSQSMessage.Add("Queue completed: " + MessageGroupId + " " + DateTime.Now.ToString(), out result);
                return new SQSBatchResponse(batchItemFailures);

            }
            catch (Exception ex)
            {
                context.Logger.LogLine($"Error {ex.Message}");
                return new SQSBatchResponse(batchItemFailures);
            }
        }

        public async Task<bool> PostInfo(Object requestObj, string methodName)
        {
            // Initialization.  
            bool isSuccess = false;

            // Posting.  
            using (var client = new HttpClient())
            {
                // Setting Base address.  
                client.BaseAddress = new Uri("https://klnbay2b4l.execute-api.us-west-1.amazonaws.com/Prod/");

                // Setting content type.                   
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                // Initialization.  
                HttpResponseMessage response = new HttpResponseMessage();

                // HTTP POST  
                var dataAsString = JsonConvert.SerializeObject(requestObj);
                var content = new StringContent(dataAsString);
                response = await client.PostAsync(methodName, content).ConfigureAwait(false);

                // Verification  
                if (response.IsSuccessStatusCode)
                {
                    // Reading Response.  
                    string result = response.Content.ReadAsStringAsync().Result;
                    isSuccess = true;
                }
            }

            return isSuccess;
        }

        public APIGatewayProxyResponse GetReadSQSMessageCount(APIGatewayProxyRequest obj, ILambdaContext context)
        {
            try
            {
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                int count = BL.ReadSQSMessage.GetReadSQSMessageCount();
                ReadSQSMessage sqs = new ReadSQSMessage();
                sqs.Count = count;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(sqs),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse GetReadSQSMessage(APIGatewayProxyRequest obj, ILambdaContext context)
        {
            try
            {
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                List<ReadSQSMessage> lstData = BLGetReadSQSMessage(out result);
                if (result.Status != BL.ResultStatus.SUCCESS)
                    throw new Exception(result.Message);
                ReadSQSMessageResposne obj1 = new ReadSQSMessageResposne();
                obj1.ReadSQSMessage = lstData;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(obj1),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public class ReadSQSMessage
        {
            public int ID { get; set; }
            public string Content { get; set; }
            public DateTime CreatedDateTime { get; set; }
            public int Count { get; set; }
            public string TaskToken { get; set; }
        }

        public static List<ReadSQSMessage> BLGetReadSQSMessage(out FunctionCallResult result)
        {
            List<ReadSQSMessage> lstEmployee = new List<ReadSQSMessage>();
            ReadSQSMessage objEmployee = new ReadSQSMessage();
            try
            {
                result = new FunctionCallResult { Status = ResultStatus.SUCCESS };
                using (IDataReader rd = BL.ReadSQSMessage.GetReadSQSMessage())
                {
                    int _ID = rd.GetOrdinal("ID"),
                        _Content = rd.GetOrdinal("Content"),
                        _CreateDateTime = rd.GetOrdinal("CreateDateTime"),
                        _AWSToken = rd.GetOrdinal("AWSToken");

                    while (rd.Read())
                    {
                        objEmployee = new ReadSQSMessage();
                        if (!rd.IsDBNull(_ID)) objEmployee.ID = rd.GetInt32(_ID);
                        if (!rd.IsDBNull(_Content)) objEmployee.Content = rd.GetString(_Content);
                        if (!rd.IsDBNull(_AWSToken)) objEmployee.TaskToken = rd.GetString(_AWSToken);
                        if (!rd.IsDBNull(_CreateDateTime)) objEmployee.CreatedDateTime = rd.GetDateTime(_CreateDateTime);
                        lstEmployee.Add(objEmployee);
                    }
                }
                return lstEmployee;
            }
            catch (Exception ex)
            {
                result = new FunctionCallResult { Status = ResultStatus.ERROR, Exception = ex, Message = ex.Message };
                return lstEmployee;
            }
        }

        public static void BLDeleteReadSQSMessage(out FunctionCallResult result)
        {
            try
            {
                result = new FunctionCallResult { Status = ResultStatus.SUCCESS };
                BL.ReadSQSMessage.DeleteReadSQSMessages();
            }
            catch (Exception ex)
            {
                result = new FunctionCallResult { Status = ResultStatus.ERROR, Exception = ex, Message = ex.Message };
            }
        }
        public class ReadSQSMessageResposne
        {
            public List<ReadSQSMessage> ReadSQSMessage { get; set; }
        }

        public APIGatewayProxyResponse TruncateTable(APIGatewayProxyRequest obj, ILambdaContext context)
        {
            try
            {
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                List<ReadSQSMessage> lstData = new List<ReadSQSMessage>();
                BLDeleteReadSQSMessage(out result);
                if (result.Status != BL.ResultStatus.SUCCESS)
                    throw new Exception(result.Message);
                ReadSQSMessageResposne obj1 = new ReadSQSMessageResposne();
                obj1.ReadSQSMessage = lstData;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(obj1),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse DescribeExecution(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                context.Logger.LogLine("Initiated");
                string requestBody = input.Body;
                POCODescribeExecution obj = JsonConvert.DeserializeObject<POCODescribeExecution>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonStepFunctionsClient req = new AmazonStepFunctionsClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = req.DescribeExecutionAsync(new Amazon.StepFunctions.Model.DescribeExecutionRequest() { ExecutionArn = obj.ExecutionArn }).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                context.Logger.LogLine("Call ended");
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                context.Logger.LogLine("Error" + ex.Message);
                return response;
            }
        }

        public APIGatewayProxyResponse GetExecutionHistory(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                //Object requestObj = new { input = "{\"Name\":\"" + "Logic Muthu" + "\"}", stateMachineArn = "arn:aws:states:us-west-1:582277656355:stateMachine:StepFunctionUsingSQS" };
                ////// Call REST Web API.  
                //Task.Run(() => PostInfo(requestObj, "StartExecution").Result);
                //Object requestObj1 = new { Msg = "Logic Muthu", QueueURL = "https://sqs.us-west-1.amazonaws.com/582277656355/My.fifo" };
                ////requestObj1 = "{\"Msg\":\"" + "Logic" + "\",\"QueueURL\":\"https://sqs.us-west-1.amazonaws.com/582277656355/My.fifo\"}";
                //Task.Run(() => PostInfo(requestObj1, "SendSQSMessages").Result);
                context.Logger.LogLine("Initiated");
                string requestBody = input.Body;
                POCODescribeExecution obj = JsonConvert.DeserializeObject<POCODescribeExecution>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonStepFunctionsClient req = new AmazonStepFunctionsClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = req.GetExecutionHistoryAsync(new Amazon.StepFunctions.Model.GetExecutionHistoryRequest() { ExecutionArn = obj.ExecutionArn }).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                context.Logger.LogLine("Call ended");
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                context.Logger.LogLine("Error" + ex.Message);
                return response;
            }
        }

        public SQSBatchResponse SFQueueReadSQSMessages(SQSEvent sqsEvent, ILambdaContext context)
        {
            List<SQSBatchResponse.BatchItemFailure> batchItemFailures = new List<SQSBatchResponse.BatchItemFailure>();
            try
            {
                Guid MessageGroupId = Guid.NewGuid();
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                //BL.ReadSQSMessage.Add("SF Queue initiated: " + MessageGroupId + " " + DateTime.Now.ToString(), out result);
                //context.Logger.LogLine($"Message Count : {sqsEvent.Records.Count}");
                //context.Logger.LogLine($"Sleep started...");
                //context.Logger.LogLine($"Beginning to process {sqsEvent.Records.Count} records...");

                foreach (var record in sqsEvent.Records)
                {
                    //context.Logger.LogLine($"Message ID: {record.MessageId}");
                    //Console.WriteLine($"Event Source: {record.EventSource}");
                    //Console.WriteLine($"Event SourceARN: {record.EventSourceArn}");

                    //context.Logger.LogLine($"Record Body:");
                    //context.Logger.LogLine(record.Body);
                    try
                    {
                        //process your message
                        //if (record.Body.Contains("Error"))
                        //    throw new Exception("Moved to DLQ");
                        //int id = BL.ReadSQSMessage.Add((record.Body + " MSGID: " + record.MessageId + " GUID: " + MessageGroupId), out result);
                        //if (result.Status != BL.ResultStatus.SUCCESS)
                        //    throw new Exception(result.Message);
                        //BL.ReadSQSMessage.Add("SF DB Added", out result);
                        //context.Logger.LogLine("Added : " + id);
                        //context.Logger.LogLine("Start StartExecutionAsync");
                        var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                        AmazonStepFunctionsClient req = new AmazonStepFunctionsClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                        var data = req.StartExecutionAsync(new Amazon.StepFunctions.Model.StartExecutionRequest() { Input = "{\"Name\":\"" + record.Body + "\"}", StateMachineArn = "arn:aws:states:us-west-1:582277656355:stateMachine:StepFunctionUsingSQS" }).Result;
                        //context.Logger.LogLine("End StartExecutionAsync");
                        //Object requestObj = new { input = "{\"Name\":\"" + record.Body + "\"}", stateMachineArn = "arn:aws:states:us-west-1:582277656355:stateMachine:StepFunctionUsingSQS" };
                        //// Call REST Web API.  
                        //bool s = PostInfo(requestObj, "StartExecution").Result;
                        //Object requestObj1 = new { Msg = record.Body, QueueURL = "https://sqs.us-west-1.amazonaws.com/582277656355/My.fifo" };
                        //Task.Run(() => PostInfo(requestObj1, "SendSQSMessages").Result);
                        //bool responseObj = PostInfo(requestObj).Result;
                        //if (!responseObj)
                        //    BL.ReadSQSMessage.Add("Error", out result);
                        //else
                        //    BL.ReadSQSMessage.Add("Success", out result);
                        //Input i = new Input();
                        //i.Name = record.Body;
                        //APIGatewayProxyRequest request = new APIGatewayProxyRequest();
                        //request.Body = "{\"QueueName\":\""+ record.Body + "\"}";
                        //CreateQueue(request, context);
                    }
                    catch (Exception e)
                    {
                        context.Logger.LogLine("Error : " + e.Message + " " + record.MessageId);
                        //Add failed message identifier to the batchItemFailures list
                        batchItemFailures.Add(new SQSBatchResponse.BatchItemFailure { ItemIdentifier = record.MessageId });
                    }
                }
                //context.Logger.LogLine("Processing complete.");
                //context.Logger.LogLine($"Processed {sqsEvent.Records.Count} records.");
                //BL.ReadSQSMessage.Add("Queue completed: " + MessageGroupId + " " + DateTime.Now.ToString(), out result);
                return new SQSBatchResponse(batchItemFailures);

            }
            catch (Exception ex)
            {
                //context.Logger.LogLine($"Error {ex.Message}");
                return new SQSBatchResponse(batchItemFailures);
            }
        }

        public string PullMessages(SQSEvent sqsEvent, ILambdaContext context)
        {
            try
            {
                Guid MessageGroupId = Guid.NewGuid();
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                BL.ReadSQSMessage.Add("PullMessages Queue initiated: " + MessageGroupId + " " + DateTime.Now.ToString(), out result);
                foreach (var record in sqsEvent.Records)
                {
                    try
                    {
                        //process your message
                        if (record.Body.Contains("Error"))
                            throw new Exception("Moved to DLQ");
                        int id = BL.ReadSQSMessage.Add((record.Body + " MSGID: " + record.MessageId + " GUID: " + MessageGroupId), out result);
                        if (result.Status != BL.ResultStatus.SUCCESS)
                            throw new Exception(result.Message);
                        BL.ReadSQSMessage.Add("DB Added", out result);
                        Object requestObj = new { input = "{\"Name\":\"" + record.Body + "\"}", stateMachineArn = "arn:aws:states:us-west-1:582277656355:stateMachine:StepFunctionUsingSQS" };
                        //// Call REST Web API.  
                        Task.Run(() => PostInfo(requestObj, "StartExecution").Result);
                        Object requestObj1 = new { Msg = record.Body, QueueURL = "https://sqs.us-west-1.amazonaws.com/582277656355/My.fifo" };
                        bool s = PostInfo(requestObj1, "SendSQSMessages").Result;
                        return $"Processed {sqsEvent.Records.Count} records.";
                    }
                    catch (Exception e)
                    {
                        context.Logger.LogLine("Error : " + e.Message + " " + record.MessageId);
                    }
                }
                return $"Processed {sqsEvent.Records.Count} records.";
            }
            catch (Exception ex)
            {
                return "Error";
            }
        }

        public async Task<Input> WebhookLambda(Input input, ILambdaContext context)
        {
            try
            {
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                context.Logger.LogLine("Webhook starts");
                int id = BL.ReadSQSMessage.Add("HTTP call:" + input.Name, out result);
                if (result.Status != BL.ResultStatus.SUCCESS)
                    throw new Exception(result.Message);
                Object obj = new { Message = input.Name };
                WebhookPostInfo(obj);
                context.Logger.LogLine("Webhook end");
                //input.Name = "Success";
                return input;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<bool> WebhookPostInfo(Object requestObj)
        {
            // Initialization.  
            bool isSuccess = false;

            // Posting.  
            using (var client = new HttpClient())
            {
                // Setting Base address.  
                client.BaseAddress = new Uri("http://webhook-dev.us-west-1.elasticbeanstalk.com/api/");

                // Setting content type.                   
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                // Initialization.  
                HttpResponseMessage response = new HttpResponseMessage();

                // HTTP POST  
                var dataAsString = JsonConvert.SerializeObject(requestObj);
                var content = new StringContent(dataAsString);
                response = await client.PostAsync("callback", content).ConfigureAwait(false);

                // Verification  
                if (response.IsSuccessStatusCode)
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    isSuccess = true;
                }
            }

            return isSuccess;
        }


        public SQSBatchResponse PythonReadSQSMessages(SQSEvent sqsEvent, ILambdaContext context)
        {
            List<SQSBatchResponse.BatchItemFailure> batchItemFailures = new List<SQSBatchResponse.BatchItemFailure>();
            try
            {
                context.Logger.LogLine("Initiated");
                Guid MessageGroupId = Guid.NewGuid();
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonStepFunctionsClient req = new AmazonStepFunctionsClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                context.Logger.LogLine("Started");
                string arn = string.Empty;
                foreach (var record in sqsEvent.Records)
                {
                    try
                    {
                        //int id = BL.ReadSQSMessage.Add(record.Body, out result);
                        //if (result.Status != BL.ResultStatus.SUCCESS)
                        //    throw new Exception(result.Message);
                        if (record.Body.Contains("KAVNIYA"))
                            arn = "arn:aws:states:us-west-1:582277656355:stateMachine:KavniyaStepFunction";
                        else if (record.Body.Contains("HDFC"))
                            arn = "arn:aws:states:us-west-1:582277656355:stateMachine:HDFCStepFunction";
                        else
                            arn = "arn:aws:states:us-west-1:582277656355:stateMachine:StepFunctionUsingSQS";
                        if (record.Body.Split('|').Length > 1)
                        {
                            arn = record.Body.Split('|')[1];
                        }
                        context.Logger.LogLine("StartExecution " + DateTime.Now.ToString());
                        var data = req.StartExecutionAsync(new Amazon.StepFunctions.Model.StartExecutionRequest() { Input = "{\"Name\":\"" + record.Body + "\"}", StateMachineArn = arn }).Result;
                        context.Logger.LogLine("StartExecution Completed " + DateTime.Now.ToString());
                    }
                    catch (Exception e)
                    {
                        context.Logger.LogLine("Error : " + e.Message + " " + record.MessageId);
                        //Add failed message identifier to the batchItemFailures list
                        batchItemFailures.Add(new SQSBatchResponse.BatchItemFailure { ItemIdentifier = record.MessageId });
                    }
                }
                context.Logger.LogLine("End");
                return new SQSBatchResponse(batchItemFailures);
            }
            catch (Exception ex)
            {
                return new SQSBatchResponse(batchItemFailures);
            }
        }

        public APIGatewayProxyResponse GetDescribeStateMachine(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                context.Logger.LogLine("Initiated");
                string requestBody = input.Body;
                UpdateStateMachineRequest obj = JsonConvert.DeserializeObject<UpdateStateMachineRequest>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonStepFunctionsClient req = new AmazonStepFunctionsClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = req.DescribeStateMachineAsync(new Amazon.StepFunctions.Model.DescribeStateMachineRequest() { StateMachineArn = obj.StateMachineArn }).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                context.Logger.LogLine("Call ended");
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                context.Logger.LogLine("Error" + ex.Message);
                return response;
            }
        }

        public APIGatewayProxyResponse ListExecutions(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                context.Logger.LogLine("Initiated");
                string requestBody = input.Body;
                UpdateStateMachineRequest obj = JsonConvert.DeserializeObject<UpdateStateMachineRequest>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonStepFunctionsClient req = new AmazonStepFunctionsClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = req.ListExecutionsAsync(new Amazon.StepFunctions.Model.ListExecutionsRequest() { StateMachineArn = obj.StateMachineArn }).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                context.Logger.LogLine("Call ended");
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                context.Logger.LogLine("Error" + ex.Message);
                return response;
            }
        }

        public async Task<Input> CallBackProcess(Input input, ILambdaContext context)
        {
            try
            {
                context.Logger.LogLine(JsonConvert.SerializeObject(input));
                BL.FunctionCallResult result = new BL.FunctionCallResult();
                int id = BL.ReadSQSMessage.Add("CallBack call - " + input.Name, out result, input.TaskToken);
                return input;
            }
            catch (Exception ex)
            {
                context.Logger.LogLine("Error" + ex.Message);
                return null;
            }
        }

        public APIGatewayProxyResponse ReleaseCallBackProcess(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                context.Logger.LogLine("Initiated");
                string requestBody = input.Body;
                Input obj = JsonConvert.DeserializeObject<Input>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonStepFunctionsClient req = new AmazonStepFunctionsClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                Object Payload1 = new { Payload = new { Name = obj.Name, ID = obj.ID, TaskToken = obj.TaskToken } };
                context.Logger.LogLine(JsonConvert.SerializeObject(obj));
                //BL.ReadSQSMessage.UpdateTaskToken(obj.ID);
                var data = req.SendTaskSuccessAsync(new Amazon.StepFunctions.Model.SendTaskSuccessRequest() { Output = JsonConvert.SerializeObject(Payload1), TaskToken = obj.TaskToken }).Result;
                //var data = req.SendTaskFailureAsync(new Amazon.StepFunctions.Model.SendTaskFailureRequest() { Cause = "sdf", Error = "dsf", TaskToken = obj.TaskToken }).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                context.Logger.LogLine("Call ended");
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                context.Logger.LogLine("Error" + ex.Message);
                return response;
            }
        }

        public APIGatewayProxyResponse ListStateMachines(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                context.Logger.LogLine("Initiated");
                string requestBody = input.Body;
                UpdateStateMachineRequest obj = JsonConvert.DeserializeObject<UpdateStateMachineRequest>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonStepFunctionsClient req = new AmazonStepFunctionsClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = req.ListStateMachinesAsync(new Amazon.StepFunctions.Model.ListStateMachinesRequest() { }).Result;
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                context.Logger.LogLine("Call ended");
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                context.Logger.LogLine("Error" + ex.Message);
                return response;
            }
        }


        #region AWS Event bridge - https://docs.aws.amazon.com/eventbridge/latest/APIReference/API_Operations.html
        public APIGatewayProxyResponse CreateEBRule(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                string requestBody = input.Body;
                //CreateEventBridgeRequest obj = new CreateEventBridgeRequest()
                //{
                //    Name = "RuleCreateInAPIv2-10",
                //    Description = "A test rule created by the API",
                //    EventBusName = "default",
                //    ScheduleExpression = "cron(0/1 * * * ? *)",
                //    FunctionArn = "arn:aws:lambda:us-west-1:582277656355:function:kavniyaawsstack-EXEProcess-qRlCI4WZdhVh",                    
                //};
                CreateEventBridgeRequest obj = JsonConvert.DeserializeObject<CreateEventBridgeRequest>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonEventBridgeClient req = new AmazonEventBridgeClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));                

                //var list = req.ListRulesAsync(new Amazon.EventBridge.Model.ListRulesRequest()
                //{
                //    EventBusName = obj.EventBusName,
                //}).Result;
                Guid uniqueID = Guid.NewGuid();
                var data = req.PutRuleAsync(new Amazon.EventBridge.Model.PutRuleRequest()
                {
                    Name = obj.Name,
                    Description = obj.Description,
                    EventBusName = obj.EventBusName,
                    ScheduleExpression = obj.ScheduleExpression,
                    State = RuleState.ENABLED,
                }).Result;

                var pushTarget = req.PutTargetsAsync(new Amazon.EventBridge.Model.PutTargetsRequest()
                {
                    EventBusName = obj.EventBusName,
                    Rule = obj.Name,
                    Targets = new List<Amazon.EventBridge.Model.Target>() { new Amazon.EventBridge.Model.Target() { Id =Convert.ToString(uniqueID), Arn = obj.FunctionArn } },
                }).Result;

                uniqueID = Guid.NewGuid();
                var lp = new Amazon.Lambda.Model.AddPermissionRequest();
                lp.FunctionName = obj.FunctionArn;
                lp.Action = "lambda:InvokeFunction";
                lp.SourceArn = data.RuleArn;
                lp.Principal = "events.amazonaws.com";
                lp.StatementId = Convert.ToString(uniqueID);

                //var lambdaClient = new AmazonLambdaClient();
                //var permissionRequest = lambdaClient.AddPermissionAsync(lp).Result;
                var permissionRequest = new Amazon.Lambda.Model.AddPermissionResponse();
                using (AmazonLambdaClient lambdaClient = new AmazonLambdaClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion)))
                {
                    permissionRequest = lambdaClient.AddPermissionAsync(lp).Result;
                };

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(permissionRequest),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse DeleteEBRule(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {                
                // Before deleting rule, we need to delete all associated targets from the rule.
                string requestBody = input.Body;                
                CreateEventBridgeRequest obj = JsonConvert.DeserializeObject<CreateEventBridgeRequest>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonEventBridgeClient req = new AmazonEventBridgeClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                Guid uniqueID = Guid.NewGuid();
                //List<string> str = new List<string>();
                //str.Add("d36eaf30-b0fa-4e6c-b327-ca150daad2cd");
                //https://docs.aws.amazon.com/eventbridge/latest/APIReference/API_RemoveTargets.html
                var data = req.RemoveTargetsAsync(new Amazon.EventBridge.Model.RemoveTargetsRequest()
                {
                    Rule = obj.Name,
                    Ids = obj.Ids,
                }).Result;
                //https://docs.aws.amazon.com/eventbridge/latest/APIReference/API_DeleteRule.html
                var data1 = req.DeleteRuleAsync(new Amazon.EventBridge.Model.DeleteRuleRequest()
                {
                    Name = obj.Name,
                    EventBusName = obj.EventBusName,
                    Force = obj.Force
                }).Result;               

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data1),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse ListEBRule(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                //https://docs.aws.amazon.com/eventbridge/latest/APIReference/API_ListRules.html
                string requestBody = input.Body;
                CreateEventBridgeRequest obj = JsonConvert.DeserializeObject<CreateEventBridgeRequest>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonEventBridgeClient req = new AmazonEventBridgeClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));               
                var data = req.ListRulesAsync(new Amazon.EventBridge.Model.ListRulesRequest()
                {                   
                }).Result;

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse ListEBTargetsByRule(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                //https://docs.aws.amazon.com/eventbridge/latest/APIReference/API_ListTargetsByRule.html
                string requestBody = input.Body;
                CreateEventBridgeRequest obj = JsonConvert.DeserializeObject<CreateEventBridgeRequest>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonEventBridgeClient req = new AmazonEventBridgeClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = req.ListTargetsByRuleAsync(new Amazon.EventBridge.Model.ListTargetsByRuleRequest()
                {
                    Rule = obj.Name
                }).Result;

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse DescribeEBRule(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                //https://docs.aws.amazon.com/eventbridge/latest/APIReference/API_DescribeRule.html
                string requestBody = input.Body;
                CreateEventBridgeRequest obj = JsonConvert.DeserializeObject<CreateEventBridgeRequest>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonEventBridgeClient req = new AmazonEventBridgeClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = req.DescribeRuleAsync(new Amazon.EventBridge.Model.DescribeRuleRequest()
                {
                    Name = obj.Name
                }).Result;

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse EnableEBRule(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                //https://docs.aws.amazon.com/eventbridge/latest/APIReference/API_EnableRule.html
                string requestBody = input.Body;
                CreateEventBridgeRequest obj = JsonConvert.DeserializeObject<CreateEventBridgeRequest>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonEventBridgeClient req = new AmazonEventBridgeClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = req.EnableRuleAsync(new Amazon.EventBridge.Model.EnableRuleRequest()
                {
                    Name = obj.Name
                }).Result;

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse DisEnableEBRule(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                //https://docs.aws.amazon.com/eventbridge/latest/APIReference/API_DisableRule.html
                string requestBody = input.Body;
                CreateEventBridgeRequest obj = JsonConvert.DeserializeObject<CreateEventBridgeRequest>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonEventBridgeClient req = new AmazonEventBridgeClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = req.DisableRuleAsync(new Amazon.EventBridge.Model.DisableRuleRequest()
                {
                    Name = obj.Name
                }).Result;

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public APIGatewayProxyResponse UpdateEBRule(APIGatewayProxyRequest input, ILambdaContext context)
        {
            try
            {
                //https://docs.aws.amazon.com/eventbridge/latest/APIReference/API_PutRule.html
                // To update rule, parameters as same as CreateRule. Unique id for update is Rule name.
                string requestBody = input.Body;
                CreateEventBridgeRequest obj = JsonConvert.DeserializeObject<CreateEventBridgeRequest>(requestBody);
                var credentials = new Amazon.Runtime.BasicAWSCredentials(accessKey, secret);
                AmazonEventBridgeClient req = new AmazonEventBridgeClient(credentials, Amazon.RegionEndpoint.GetBySystemName(AWSRegion));
                var data = req.PutRuleAsync(new Amazon.EventBridge.Model.PutRuleRequest()
                {
                    Name = obj.Name,
                    ScheduleExpression = "cron(0/1 * * * ? *)",
                    State = RuleState.ENABLED,
                }).Result;

                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JsonConvert.SerializeObject(data),
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new APIGatewayProxyResponse
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = ex.Message,
                    Headers = new Dictionary<string, string> { { "Content-Type", "text/plain" } }
                };
                return response;
            }
        }

        public class CreateEventBridgeRequest
        {
            public string EventBusName { get; set; }
            public string Description { get; set; }
            public string EventPattern { get; set; }
            public string Name { get; set; }
            public string RoleArn { get; set; }
            public string ScheduleExpression { get; set; }
            public string FunctionArn { get; set; }
            public bool Force { get; set; }
            public List<string> Ids { get; set; }
        }
        #endregion
    }
}
